//
//  CPSDK.swift
//  PaymentSDK
//
//  Created by Patel, Varun on 2/8/19.
//  Copyright © 2019 First Data. All rights reserved.
//

import UIKit
import AuthenticationServices

// swiftlint:disable identifier_name
@objc public enum Environment: Int {
    case cat
    case cat_v2
    case prod
    case prod_v2
    
    func isVersion2() -> Bool {
        switch self {
        case .cat_v2, .prod_v2:
            return true
        default:
            return false
        }
    }
    
    func rawStringValue() -> String {
        switch self {
        case .cat: return "cat"
        case .cat_v2: return "cat_v2"
        case .prod: return "prod"
        case .prod_v2: return "prod_v2"
        }
    }
}
// swiftlint:enable identifier_name

/**********************************************************
 *
 * CPSDK -> Entry Point to CP-SDK Flows
 *
 **********************************************************/
// MARK: - CPDSK

@objcMembers
public class CPSdkConfiguration: NSObject {
    public let fdCustomerId: String
    public let fdAccountId: String
    public let encryptionKey: String
    public let accessToken: String
    public let configId: String
    public let postUrl: String
    public var branding: [String: String]?
    public let deepLinkPath: String
    public let skipDarkMode: Bool
    public let customLoaderJSONName: String?

    @objc public init(
        withFdCustomerId fdCustomerId: String,
        fdAccountId: String,
        encryptionKey: String,
        accessToken: String,
        configId: String,
        postUrl: String,
        deepLinkPath: String,
        aggregatorKey: String = "",
        branding: [String: String]? = nil,
        skipDarkMode: Bool = false,
        customLoaderJSONFileName: String? = nil
    ) {
        
        self.fdCustomerId = fdCustomerId
        self.fdAccountId = fdAccountId
        self.encryptionKey = encryptionKey
        self.accessToken = accessToken
        self.configId = configId
        self.postUrl = postUrl
        self.deepLinkPath = deepLinkPath
        self.skipDarkMode = skipDarkMode
        self.customLoaderJSONName = customLoaderJSONFileName
                
        CPBankLoginViewModelHelper.shared.allDataSessionID = aggregatorKey
        /// Store custom loader JsonName and visibility preference to utilise across the SDK flows
        CPUtility.shared.customLoaderJsonFileName = customLoaderJSONFileName
        if let branding = branding {
            CPUtility.shared.brandingDetails = branding
        }
    }

    var environment: Environment {
        return ConfigurationManager.shared.environment
    }
    
    var baseUrl: String {
        return endpoint(for: environment.rawStringValue())
    }
    
    private func endpoint(for environment: String) -> String {
        if environment == "cat_v2" {
            return "https://connect-cert.fiservapis.com/pbb"
        } else if environment == "prod_v2" {
            return "https://connect.fiservapis.com/pbb"
        } else if environment.hasSuffix("_v2") {
            let env = environment.replacingOccurrences(of: "_v2", with: "")
            return "https://connect-\(env).fiservapis.com/pbb"
        } else {
            return "https://\(environment).api.firstdata.com/gateway/v2/connectpay"
        }
    }
}

@objc public class CPSDK: NSObject {
    @objc public init(
        withApiKey apiKey: String,
        andEnvironment environment: Environment
    ) {
        self._environment = environment
        ConfigurationManager.shared.apiKey = apiKey
        ConfigurationManager.shared.environment = environment
        CPCustomFontLoader.loadFonts()
    }
    // TODO: Add Different SDK targets to control the below (QA/CAT/PROD)
    private var _environment = Environment.cat_v2
    private var currentflow: CPBaseFlowProtocol?
    
    @objc public func closeAccount(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andCloseAccountConfiguration closeAccountConfiguration: CloseAccountConfiguration
    ) -> CloseAccount? {
        currentflow = CloseAccount(
            cpSdkConfiguration: cpSdkConfiguration,
            closeAccountConfiguration: closeAccountConfiguration
        )
        
        return currentflow as? CloseAccount
    }
    
    @objc public func manualEnrollment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andManualEnrollmentConfiguration manualEnrollmentConfiguration: ManualEnrollmentConfiguration
    ) -> ManualEnrollment? {
        currentflow = ManualEnrollment(
            cpSdkConfiguration: cpSdkConfiguration,
            manualEnrollmentConfiguration: manualEnrollmentConfiguration
        )
        
        return currentflow as? ManualEnrollment
    }
    
    @objc public func updateEnrollment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andUpdateEnrollmentConfiguration updateEnrollmentConfiguration: ManualEnrollmentConfiguration
    ) -> UpdateEnrollment? {
        currentflow = UpdateEnrollment(
            cpSdkConfiguration: cpSdkConfiguration,
            updateEnrollmentConfiguration: updateEnrollmentConfiguration
        )
        
        return currentflow as? UpdateEnrollment
    }
    
    @objc public func manualDeposit(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andManualDepositConfiguration manualDepositConfiguration: ManualDepositConfiguration
    ) -> ManualDeposit? {
        currentflow = ManualDeposit(
            cpSdkConfiguration: cpSdkConfiguration,
            manualDepositConfiguration: manualDepositConfiguration
        )
        
        return currentflow as? ManualDeposit
    }
    
    @objc public func accountValidation(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andAccountValidationConfiguration accountValidationConfiguration: AccountValidationConfiguration
    ) -> AccountValidation? {
        currentflow = AccountValidation(
            cpSdkConfiguration: cpSdkConfiguration,
            accountValidationConfiguration: accountValidationConfiguration
        )
        
        return currentflow as? AccountValidation
    }
    
    @objc public func enrollmentAccountDetail(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andEnrollmentAccountDetailConfiguration enrollmentAccountDetailConfiguration: ManualEnrollmentConfiguration
    ) -> EnrollmentAccountDetails? {
        currentflow = EnrollmentAccountDetails(
            cpSdkConfiguration: cpSdkConfiguration,
            enrollmentAccountDetailConfiguration: enrollmentAccountDetailConfiguration
        )
        
        return currentflow as? EnrollmentAccountDetails
    }
    
    @objc public func relinkEnrolment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andRelinkEnrolmentConfiguration relinkConfiguration: RelinkEnrolmentConfiguration
    ) -> RelinkEnrolment? {
        currentflow = RelinkEnrolment(
            cpSdkConfiguration: cpSdkConfiguration,
            relinkEnrolmentConfiguration: relinkConfiguration
        )
        
        return currentflow as? RelinkEnrolment
    }
    
    @objc public func streamlinedEnrollment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andStreamlinedEnrollmentConfiguration streamlinedConfiguration: StreamlinedEnrollmentConfiguration
    ) -> StreamlinedEnrollment? {
        let currentflow = StreamlinedEnrollment(
            cpSdkConfiguration: cpSdkConfiguration,
            streamlinedEnrollmentConfiguration: streamlinedConfiguration
        )
        return currentflow as StreamlinedEnrollment
    }
    
    @objc public func transparentEnrollment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andTransparentConfiguration transparentConfiguration: TransparentWidgetConfiguration
    ) -> TransparentWidgetEnrollment? {
        return TransparentWidgetEnrollment(
            cpSdkConfiguration: cpSdkConfiguration,
            transparentEnrollmentConfiguration: transparentConfiguration
        )
    }
    
    @objc public func purchasePaymentEnrollment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andPurchasePaymentConfiguration purchasePaymentEnrollmentConfiguration: PurchasePaymentConfiguration
    ) -> PurchasePayment? {
        return PurchasePayment(
            cpSdkConfiguration: cpSdkConfiguration,
            purchasePaymentConfiguration: purchasePaymentEnrollmentConfiguration
        )
    }
    
    @objc public func authorizePaymentEnrollment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andAuthorizePaymentConfiguration authorizePaymentEnrollmentConfiguration: AuthorizePaymentConfiguration
    ) -> AuthorizePayment? {
        return AuthorizePayment(
            cpSdkConfiguration: cpSdkConfiguration,
            authorizePaymentConfiguration: authorizePaymentEnrollmentConfiguration
        )
    }
    
    @objc public func guestCheckoutEnrollment(
        withCpSdkConfiguration cpSdkConfiguration: CPSdkConfiguration,
        andGuestCheckoutConfiguration guestCheckoutEnrollmentConfiguration: GuestCheckoutConfiguration
    ) -> GuestCheckoutPayment? {
        return GuestCheckoutPayment(
            cpSdkConfiguration: cpSdkConfiguration,
            guestCheckoutEnrollmentConfiguration: guestCheckoutEnrollmentConfiguration
        )
    }
}
