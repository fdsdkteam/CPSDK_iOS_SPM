//
//  PaymentSDK.h
//  PaymentSDK
//
//  Created by Patel, Varun on 11/15/18.
//  Copyright © 2018 First Data. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PaymentSDK.
FOUNDATION_EXPORT double PaymentSDKVersionNumber;

//! Project version string for PaymentSDK.
FOUNDATION_EXPORT const unsigned char PaymentSDKVersionString[];

#import <PaymentSDK/LBProfilingConnections.h>

// In this header, you should import all the public headers of your framework using statements like #import <PaymentSDK/PublicHeader.h>


